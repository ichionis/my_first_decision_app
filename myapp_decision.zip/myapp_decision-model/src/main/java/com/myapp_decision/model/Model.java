package com.myapp_decision.model;


public class Model {


}